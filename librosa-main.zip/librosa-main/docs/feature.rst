.. _feature:

.. automodule:: librosa.feature
