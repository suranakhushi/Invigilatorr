.. _beat:

.. automodule:: librosa.beat

